
# Note
This is my personal repository not but official repository.

# Branches
- original
    - Follow vim.org changes.
- master
    - "original" branch with my hacks.
- hack/...
    - My misc. hacks.
